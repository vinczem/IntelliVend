# IntelliVend Tools

Ez a könyvtár különböző fejlesztési és tesztelési eszközöket tartalmaz.

---

## 🤖 ESP32 Mock Client (`esp32_mock.py`)

Python alapú MQTT kliens, amely **szimulálja az ESP32 viselkedését**. Használható a backend és frontend teszteléséhez, mielőtt a tényleges ESP32 firmware elkészülne.

### ✨ Funkciók

- ✅ **Dispense szimuláció** - Italadagolás real-time progress update-ekkel (500ms)
- ✅ **Maintenance flush** - Pumpa öblítés szimuláció (egyedi és bulk)
- ✅ **Calibration** - Flow meter kalibráció szimuláció
- ✅ **Emergency stop** - Vészleállítás kezelés
- ✅ **Heartbeat** - Rendszeres állapot jelentés (10s)
- ✅ **Error injection** - Véletlen hibák generálása teszteléshez

### 📦 Telepítés

```bash
# Python 3.7+ szükséges
pip install paho-mqtt
```

### 🚀 Használat

**Alap futtatás** (default broker: 192.168.0.55:1883)
```bash
cd /Users/vmihaly/dev/IntelliVend/tools
python3 esp32_mock.py
```

**Username és password használatával** (ha az MQTT broker autentikációt igényel)
```bash
python3 esp32_mock.py --username mqtt_user --password secret123
```

**Egyedi MQTT broker**
```bash
python3 esp32_mock.py --broker 192.168.1.100 --port 1883
```

**Hibák generálása teszteléshez** (10% esély hibára)
```bash
python3 esp32_mock.py --error-rate 0.1
```

**Háttérben futtatás**
```bash
python3 esp32_mock.py > /dev/null 2>&1 &

# Leállítás:
pkill -f esp32_mock.py
```

### 📡 MQTT Topics

A mock client az alábbi topicokat használja (MQTT Protocol v2.0):

**Subscribed (parancsok fogadása):**
- `intellivend/dispense/command` (QoS 1)
- `intellivend/maintenance/flush` (QoS 1)
- `intellivend/calibration/start` (QoS 1)
- `intellivend/emergency/stop` (QoS 2)

**Published (válaszok küldése):**
- `intellivend/status` (QoS 0) - 500ms-enként progress update
- `intellivend/dispense/complete` (QoS 1) - Adagolás befejezve
- `intellivend/maintenance/complete` (QoS 1) - Karbantartás befejezve
- `intellivend/error` (QoS 1) - Hibajelzések
- `intellivend/heartbeat` (QoS 0, retained) - 10s-enként állapot

### 🧪 Tesztelési példák

**1. Backend indítás**
```bash
cd /Users/vmihaly/dev/IntelliVend/backend
/usr/local/bin/node server.js
```

**2. Mock ESP32 indítás** (új terminálban)
```bash
cd /Users/vmihaly/dev/IntelliVend/tools
python3 esp32_mock.py
```

**3. Teszt parancs küldése** (harmadik terminálban)
```bash
# Italadagolás teszt (10ml, 1. pumpa)
mosquitto_pub -h 192.168.0.55 -t "intellivend/dispense/command" -m '{
  "pump_id": 1,
  "amount_ml": 10.0,
  "duration_ms": 3000,
  "recipe_name": "Test Drink",
  "timestamp": "2025-11-02T10:00:00Z"
}'

# Pumpa öblítés (5 másodperc)
mosquitto_pub -h 192.168.0.55 -t "intellivend/maintenance/flush" -m '{
  "pump_id": 1,
  "duration_ms": 5000
}'

# Összes pumpa öblítése (bulk)
mosquitto_pub -h 192.168.0.55 -t "intellivend/maintenance/flush" -m '{
  "pump_id": -1,
  "duration_ms": 3000
}'

# Emergency stop
mosquitto_pub -h 192.168.0.55 -t "intellivend/emergency/stop" -q 2 -m '{
  "reason": "Manual test"
}'
```

**4. MQTT üzenetek figyelése** (negyedik terminálban, opcionális)
```bash
# Minden üzenet
mosquitto_sub -h 192.168.0.55 -t "intellivend/#" -v

# Csak status update-ek
mosquitto_sub -h 192.168.0.55 -t "intellivend/status"

# Csak heartbeat
mosquitto_sub -h 192.168.0.55 -t "intellivend/heartbeat"
```

### 🎭 Szimuláció részletei

**Dispense folyamat:**
1. Backend küld `dispense/command` parancsot
2. Mock ESP32 fogadja, elkezdi az adagolást
3. 500ms-enként `status` üzenet (progress_ml, flow_rate, elapsed_ms)
4. Befejezéskor `dispense/complete` üzenet
   - `actual_ml` = requested_ml ± 5% (realisztikus szórás)
5. Backend frissíti az inventory-t

**Flush folyamat:**
1. Backend küld `maintenance/flush` parancsot
2. Mock ESP32 szimulálja az öblítést
3. Befejezéskor `maintenance/complete` üzenet
4. Backend naplózza a maintenance_log táblába

**Heartbeat:**
- Küldési gyakoriság: 10 másodperc
- Tartalom:
  - `uptime_ms` - működési idő
  - `wifi_rssi` - WiFi jelerősség (-30 ~ -90 dBm)
  - `free_heap` / `total_heap` - memória használat
  - `pumps_active` - aktív pumpák száma
  - `firmware_version` - "MOCK_v1.0.0"

**Error injection:**
- `--error-rate 0.1` kapcsolóval 10% esély hibára
- Lehetséges hibakódok:
  - `PUMP_STUCK` - Pumpa elakadt
  - `FLOW_SENSOR_ERROR` - Flow meter hiba
  - `TIMEOUT` - Időtúllépés
  - `EMERGENCY_STOP` - Vészleállítás

### 📊 Kimenet példa

```
============================================================
🤖 IntelliVend ESP32 Mock Client
============================================================
Broker: 192.168.0.55:1883
Error rate: 0.0%
============================================================

✅ [ESP32] Connected to MQTT broker 192.168.0.55:1883
📡 [ESP32] Subscribed to: intellivend/dispense/command (QoS 1)
📡 [ESP32] Subscribed to: intellivend/maintenance/flush (QoS 1)
📡 [ESP32] Subscribed to: intellivend/calibration/start (QoS 1)
📡 [ESP32] Subscribed to: intellivend/emergency/stop (QoS 2)
💓 [ESP32] Heartbeat thread started

📨 [ESP32] Received on intellivend/dispense/command:
   {
      "pump_id": 1,
      "amount_ml": 50.0,
      "duration_ms": 5000,
      "recipe_name": "Mojito"
   }
🚀 [ESP32] Starting dispense: Pump 1, 50.0ml, 5000ms
📊 [ESP32] Status: 0.0/50.0ml (0%)
📊 [ESP32] Status: 5.0/50.0ml (10%)
📊 [ESP32] Status: 10.0/50.0ml (20%)
...
📊 [ESP32] Status: 50.0/50.0ml (100%)
✅ [ESP32] Dispense complete: 48.7ml dispensed

💓 [ESP32] Heartbeat sent (uptime: 30s, WiFi: -65dBm)
```

### 🔄 WebSocket fejlesztéshez

Ez a mock client **tökéletes a WebSocket integráció teszteléséhez**:

1. Backend WebSocket server feliratkozik az MQTT üzenetekre
2. Mock ESP32 küld `status` üzeneteket 500ms-enként
3. WebSocket broadcast a frontend-nek
4. Frontend real-time progress bar frissül

### 🛠️ Fejlesztési jegyzetek

- **Átmeneti eszköz**: A mock client később elhagyható, amint az ESP32 firmware elkészül
- **Referencia**: Jó kiindulópont az ESP32 firmware írásakor (ugyanazok a payloadok)
- **Tesztelés**: Edge case-ek egyszerűen szimulálhatók (hibák, timeout-ok)

### 📝 TODO

- [ ] WebSocket real-time updates (frontend integráció)
- [ ] Mock client GUI (tkinter vagy web-based)
- [ ] Több ESP32 szimuláció egyszerre (multi-instance)

---

## 📄 Licenc

MIT License - IntelliVend projekt része
